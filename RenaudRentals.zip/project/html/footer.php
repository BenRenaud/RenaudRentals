<footer class="page-footer font-small blue pt-4">
  <div class="footer-copyright text-center py-3"><strong>Contact Us:</strong> (519)-996-3476 | RenaudRentals@gmail.com
  </div>
</footer>